<div class="channel-manager-container">
    <!-- Channel Navigation Section -->
    <section class="live-channel-nav">
        <div class="container">
            <div class="live-channel-nav-wrapper">
                <button class="live-channel-nav-arrow-btn left-arrow" aria-label="Scroll left">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <div class="live-channel-scroll-container">
                    <div class="live-channel-scroll-items">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="live-channel-nav-item <?php echo e($selectedChannel === $channel['id'] ? 'active' : ''); ?>" 
                                wire:click="selectChannel('<?php echo e($channel['id']); ?>')">
                                <div class="live-channel-nav-icon">
                                    <img src="<?php echo e($channel['logo']); ?>" alt="<?php echo e($channel['name']); ?>" class="live-channel-nav-img">
                                </div>
                                <span class="live-channel-nav-name"><?php echo e($channel['name']); ?></span>
                                <!--[if BLOCK]><![endif]--><?php if($channel['is_live']): ?>
                                    <span class="badge bg-danger ms-2">LIVE</span>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
                <button class="live-channel-nav-arrow-btn right-arrow" aria-label="Scroll right">
                    <i class="fas fa-chevron-right"></i>
                </button>
            </div>
        </div>
    </section>

    <!-- Main Content Section -->
    <section class="live-main">
        <div class="container">
            <div class="row g-4">
                <!-- Left Column: Channel Activities -->
                <div class="col-lg-3">
                    <!--[if BLOCK]><![endif]--><?php if($selectedChannel): ?>
                        <!--[if BLOCK]><![endif]--><?php if($selectedChannel === 'all'): ?>
                            <div class="live-channel-activities">
                                <div class="channel-header">
                                    <img src="https://img.zuzz.tv/assets/logo.png" alt="All Channels" class="channel-logo">
                                    <h3 class="channel-title">All Channels</h3>
                                </div>
                                <div class="activities-list">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <!--[if BLOCK]><![endif]--><?php if($channel['id'] !== 'all'): ?>
                                            <div class="activity-item <?php echo e($selectedChannel === $channel['id'] ? 'active' : ''); ?>" wire:click="selectChannel('<?php echo e($channel['id']); ?>')">
                                                <div class="channel-info mb-2">
                                                    <img src="<?php echo e($channel['logo']); ?>" alt="<?php echo e($channel['name']); ?>" class="channel-logo-sm">
                                                    <h4 class="channel-title-sm"><?php echo e($channel['name']); ?></h4>
                                                    <!--[if BLOCK]><![endif]--><?php if($channel['is_live']): ?>
                                                        <span class="badge bg-danger ms-2">LIVE</span>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </div>
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        <?php elseif(isset($channelActivities[$selectedChannel])): ?>
                            <?php
                                $currentChannel = collect($channels)->firstWhere('id', $selectedChannel);
                            ?>
                            <div class="live-channel-activities">
                                <div class="channel-header">
                                    <img src="<?php echo e($currentChannel['logo']); ?>" alt="<?php echo e($currentChannel['name']); ?>" class="channel-logo">
                                    <h3 class="channel-title"><?php echo e($currentChannel['name']); ?></h3>
                                </div>
                                
                                <!--[if BLOCK]><![endif]--><?php if(!$isPlaying): ?>
                                    <button class="btn btn-warning w-100 mb-3" wire:click="startStreaming('<?php echo e($selectedChannel); ?>')" 
                                        wire:loading.attr="disabled">
                                        <span wire:loading.remove>
                                            <i class="fas fa-play me-2"></i> Watch Now
                                        </span>
                                        <span wire:loading>
                                            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                            Loading...
                                        </span>
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-danger w-100 mb-3" wire:click="stopStreaming">
                                        <i class="fas fa-stop me-2"></i> Stop
                                    </button>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                
                                <div class="activities-list">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $channelActivities[$selectedChannel]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="activity-item">
                                            <div class="activity-time">
                                                <?php echo e(date('H:i', strtotime($activity['time']))); ?>

                                            </div>
                                            <div class="activity-details">
                                                <h4><?php echo e($activity['title']); ?></h4>
                                                <p><?php echo e(date('l d F', strtotime($activity['date']))); ?></p>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <!-- Right Column: Video Player -->
                <div class="col-lg-9">
                    <div class="live-content-area">
                        <!--[if BLOCK]><![endif]--><?php if($streamError): ?>
                            <div class="alert alert-danger">
                                <?php echo e($streamError); ?>

                                <button class="btn btn-sm btn-warning float-end" wire:click="startStreaming('<?php echo e($selectedChannel); ?>')">
                                    Retry
                                </button>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <!--[if BLOCK]><![endif]--><?php if($isPlaying && $selectedChannel && $selectedChannel !== 'all'): ?>
                            <?php
                                $currentChannel = collect($channels)->firstWhere('id', $selectedChannel);
                            ?>
                            <!--[if BLOCK]><![endif]--><?php if($currentChannel): ?>
                                <div class="live-video-container">
                                    <!--[if BLOCK]><![endif]--><?php if($isPlaying && $selectedChannel && $selectedChannel !== 'all'): ?>
                                        <video id="my_video_1" class="video-js vjs-default-skin vjs-fluid" 
                                            controls preload="auto" playsinline webkit-playsinline>
                                            <!--[if BLOCK]><![endif]--><?php if($isPlaying && $selectedChannel && $selectedChannel !== 'all'): ?>
                                                <source src="<?php echo e($currentChannel['stream_link']); ?>" type="application/x-mpegURL">
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </video>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <?php else: ?>
                            <div class="placeholder-container d-flex align-items-center justify-content-center">
                                <div class="text-center">
                                    <i class="fas fa-tv fa-5x text-muted mb-3"></i>
                                    <h3 class="text-muted">Select a channel to start streaming</h3>
                                    <p class="text-muted">Choose from the available channels on the left</p>
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('livewire:init', () => {
        let player = null;

        function initializePlayer() {
            // Dispose existing player if any
            if (player) {
                player.dispose();
                player = null;
            }

            // Only initialize if we should be playing
            if (window.Livewire.find('<?php echo e($_instance->getId()); ?>').isPlaying && window.Livewire.find('<?php echo e($_instance->getId()); ?>').selectedChannel && window.Livewire.find('<?php echo e($_instance->getId()); ?>').selectedChannel !== 'all') {
                player = videojs('my_video_1', {
                    fluid: true,
                    html5: {
                        hls: {
                            overrideNative: true,
                            withCredentials: false
                        }
                    },
                    autoplay: true,
                    muted: false, // Required for autoplay in most browsers
                    liveui: true
                });

                // Handle autoplay restrictions
                const playPromise = player.play();

                if (playPromise !== undefined) {
                    playPromise.catch(error => {
                        console.log('Autoplay prevented:', error);
                        // Show play button overlay
                        document.getElementById('playOverlay').style.display = 'flex';
                    });
                }
            }
        }

        // Initialize when stream starts
        Livewire.on('streamStarted', () => {
            setTimeout(initializePlayer, 100);
        });

        // Clean up when stream stops
        Livewire.on('streamStopped', () => {
            if (player) {
                player.dispose();
                player = null;
            }
        });

        // Initialize on page load if needed
        initializePlayer();

        // Reinitialize when Livewire updates the DOM
        Livewire.hook('message.processed', () => {
            if (window.Livewire.find('<?php echo e($_instance->getId()); ?>').isPlaying) {
                setTimeout(initializePlayer, 100);
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>


<?php /**PATH D:\pro_projects\live_tv\justTv\justtv\resources\views/livewire/channel-manager.blade.php ENDPATH**/ ?>