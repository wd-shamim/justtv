    <!-- Footer -->
    <footer class="live-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p class="live-copyright">Copyright © 2024 ZUZZ TV</p>
                </div>
                <div class="col-md-6">
                    <ul class="live-footer-links">
                        <li><a href="#">Terms And Conditions</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Affiliates</a></li>
                        <li><a href="#">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>