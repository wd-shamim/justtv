@extends('web.layout.master')
@section('content')
        @livewire('channel-manager')
@endsection